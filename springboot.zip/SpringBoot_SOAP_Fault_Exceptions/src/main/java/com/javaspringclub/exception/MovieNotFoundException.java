package com.javaspringclub.exception;

import org.springframework.ws.soap.server.endpoint.annotation.FaultCode;
import org.springframework.ws.soap.server.endpoint.annotation.SoapFault;
/* @SoapFault(faultCode = FaultCode.CUSTOM,locale="en",faultStringOrReason = "CUSTOM_MESSAGE",customFaultCode="YOUR_NAMESPACE + YOUR_CUSTOM_CODE")
*/
@SoapFault(faultCode = FaultCode.CUSTOM,
        customFaultCode = "{" + MovieNotFoundException.NAMESPACE_URI + "}MOVIE_NOT_FOUND",
        faultStringOrReason = "@faultString")
public class MovieNotFoundException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	public static final String NAMESPACE_URI = "http://javaspringclub.com/exception";

	public MovieNotFoundException() {
		super();
	}
	
    public MovieNotFoundException(String message) {
        super(message);
    }
}
