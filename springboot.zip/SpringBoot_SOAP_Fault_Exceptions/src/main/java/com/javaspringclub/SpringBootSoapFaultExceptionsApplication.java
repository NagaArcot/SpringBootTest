package com.javaspringclub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootSoapFaultExceptionsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootSoapFaultExceptionsApplication.class, args);
	}
}
