package com.javaspringclub.client;

import org.springframework.ws.client.core.support.WebServiceGatewaySupport;

import com.javaspringclub.gs_ws.GetMovieByIdRequest;
import com.javaspringclub.gs_ws.GetMovieByIdResponse;

public class MovieClient extends WebServiceGatewaySupport {

	public GetMovieByIdResponse getMovieById(Long id) {
		GetMovieByIdRequest request = new GetMovieByIdRequest();
		request.setMovieId(id);
		return (GetMovieByIdResponse) getWebServiceTemplate().marshalSendAndReceive(request);
	}
}