package com.javaspringclub.client;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.javaspringclub.gs_ws.GetMovieByIdResponse;
import com.javaspringclub.gs_ws.MovieType;

public class RunClient {
    public static void main(String[] args) {
    	
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(SoapClientConfig.class);
        MovieClient client = context.getBean(MovieClient.class);
        GetMovieByIdResponse response = client.getMovieById(new Long(2));
        MovieType m = response.getMovieType();
        System.out.println("Response: Id="+ m.getMovieId() + ", Title="+m.getTitle()+ ", Category="+m.getCategory());
    }

}
