package com.javaspringclub.server;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.stereotype.Component;

import com.javaspringclub.gs_ws.MovieType;
import com.javaspringclub.gs_ws.ServiceStatus;

@Component
public class MovieService {

	public enum Status {
		SUCCESS, FAILURE;
	}

	private static List<MovieType> movies = new ArrayList<>();

	static {
		MovieType movie1 = new MovieType();
		movie1.setMovieId(101);
		movie1.setTitle("Mission Impossible");
		movie1.setCategory("Action");

		movies.add(movie1);

		MovieType movie2 = new MovieType();
		movie2.setMovieId(102);
		movie2.setTitle("Argo");
		movie2.setCategory("Drama");
		movies.add(movie2);

		MovieType movie3 = new MovieType();
		movie3.setMovieId(103);
		movie3.setTitle("Hang over");
		movie3.setCategory("Comedy");
		movies.add(movie3);

	}

	// Get Movie By Id - 1
	public MovieType findById(long id) {
		for (MovieType movie : movies) {
			if (movie.getMovieId() == id)
				return movie;
		}
		return null;
	}

	// Get All movies
	public List<MovieType> findAll() {
		return movies;
	}

	public ServiceStatus deleteById(int id) {
		Iterator<MovieType> iterator = movies.iterator();
		ServiceStatus status = new ServiceStatus();
		while (iterator.hasNext()) {
			MovieType movie = iterator.next();
			if (movie.getMovieId() == id) {
				iterator.remove();
				// return Status.SUCCESS;

				status.setStatusCode("OK");
				status.setMessage("SUCCESS");
				return status;
			}
		}
		// return Status.FAILURE;
		status.setStatusCode("ERROR");
		status.setMessage("FAILURE");
		return status;
	}

	// updating course & new course
}
